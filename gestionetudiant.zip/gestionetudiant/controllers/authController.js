// controllers/authController.js
const bcrypt = require('bcrypt');
const db = require('../models/db');

exports.loginPage = (req, res) => {
  res.render('login');
};

exports.login = (req, res) => {
  const { username, password } = req.body;

  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err) return res.status(500).send('Erreur serveur');
    if (results.length === 0) return res.status(401).send('Utilisateur non trouvé');

    const user = results[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).send('Mot de passe incorrect');

    req.session.user = { id: user.id, username: user.username, role: user.role };
    res.redirect('/etudiants');
  });
};

exports.registerPage = (req, res) => {
  res.render('register');
};

exports.register = async (req, res) => {
  const { username, email, password, role } = req.body;

  if (!username || !email || !password) {
    return res.send('Tous les champs sont obligatoires');
  }

  // Vérifier si le nom d'utilisateur existe déjà
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err) return res.status(500).send('Erreur serveur');
    if (results.length > 0) return res.send('Nom d\'utilisateur déjà pris');

    // Hasher le mot de passe
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insertion correcte dans la base de données
    db.query(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, role || 'utilisateur'],
      (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Erreur lors de l\'inscription');
        }
        res.redirect('/login');
      }
    );
  });
};


exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
};
