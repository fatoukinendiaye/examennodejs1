// controllers/etudiantController.js
const db = require('../models/db'); // ta connexion à la base

exports.listEtudiants = (req, res) => {
  db.query('SELECT * FROM etudiants', (err, results) => {
    if (err) return res.status(500).send(err);
    res.render('index', { etudiants: results });
  });
};

exports.formAjouterEtudiant = (req, res) => {
  res.render('add');  // page add.ejs
};

exports.ajouterEtudiant = (req, res) => {
  const { nom, prenom, adresse, sexe, nationalite, matricule, filiere, universite, date_naissance, classe } = req.body;
  const sql = `INSERT INTO etudiants (nom, prenom, adresse, sexe, nationalite, matricule, filiere, universite, date_naissance, classe) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  const values = [nom, prenom, adresse, sexe, nationalite, matricule, filiere, universite, date_naissance, classe];
  db.query(sql, values, (err) => {
    if (err) return res.status(500).send(err);
    res.redirect('/etudiants');
  });
};

exports.formModifierEtudiant = (req, res) => {
  if (req.session.user.role !== 'admin') {
    return res.status(403).send('⛔ Accès interdit : seuls les administrateurs peuvent modifier.');
  }

  const id = req.params.id;
  db.query('SELECT * FROM etudiants WHERE id = ?', [id], (err, results) => {
    if (err) return res.status(500).send(err);
    if (results.length === 0) return res.status(404).send('Étudiant non trouvé');
    res.render('edit', { etudiant: results[0] });
  });
};


exports.modifierEtudiant = (req, res) => {
  if (req.session.user.role !== 'admin') {
    return res.status(403).send('⛔ Vous n\'êtes pas autorisé à modifier les étudiants.');
  }

  const id = req.params.id;
  const { nom, prenom, adresse, sexe, nationalite, matricule, filiere, universite, date_naissance, classe } = req.body;

  const sql = `UPDATE etudiants SET nom=?, prenom=?, adresse=?, sexe=?, nationalite=?, matricule=?, filiere=?, universite=?, date_naissance=?, classe=? WHERE id=?`;
  const values = [nom, prenom, adresse, sexe, nationalite, matricule, filiere, universite, date_naissance, classe, id];

  db.query(sql, values, (err) => {
    if (err) return res.status(500).send(err);
    res.redirect('/etudiants');
  });
};


exports.supprimerEtudiant = (req, res) => {
  if (req.session.user.role !== 'admin') {
    return res.status(403).send('⛔ Suppression non autorisée : accès réservé aux administrateurs.');
  }

  const id = req.params.id;
  db.query('DELETE FROM etudiants WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).send(err);
    res.redirect('/etudiants');
  });
};

