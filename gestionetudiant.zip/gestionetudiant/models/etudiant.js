const db = require('./db');

exports.getAll = (callback) => {
  db.query('SELECT * FROM etudiants', callback);
};

exports.getById = (id, callback) => {
  db.query('SELECT * FROM etudiants WHERE id = ?', [id], callback);
};

exports.create = (data, callback) => {
  db.query('INSERT INTO etudiants SET ?', data, callback);
};

exports.update = (id, data, callback) => {
  db.query('UPDATE etudiants SET ? WHERE id = ?', [data, id], callback);
};

exports.remove = (id, callback) => {
  db.query('DELETE FROM etudiants WHERE id = ?', [id], callback);
};
