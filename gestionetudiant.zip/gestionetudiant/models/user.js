const db = require('./db');

exports.findByUsername = (username, callback) => {
  db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
    if (err) return callback(err);
    callback(null, results[0]);
  });
};

exports.createUser = (user, callback) => {
  const { username, email, password, role } = user;
  db.query(
    'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
    [username, email, password, role],
    (err, result) => {
      if (err) return callback(err);
      callback(null, result);
    }
  );
};
