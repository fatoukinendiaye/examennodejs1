const express = require('express');
const router = express.Router();
const etudiantController = require('../controllers/etudiantController');

// Exemple d'une route GET avec un contrôleur
router.get('/', etudiantController.listEtudiants);

// Route GET formulaire ajout étudiant
router.get('/ajouter', etudiantController.formAjouterEtudiant);

// Route POST ajout étudiant
router.post('/ajouter', etudiantController.ajouterEtudiant);

// Route GET formulaire modifier étudiant
router.get('/edit/:id', etudiantController.formModifierEtudiant);

// Route POST modifier étudiant
router.post('/edit/:id', etudiantController.modifierEtudiant);

// Route GET supprimer étudiant
router.get('/supprimer/:id', etudiantController.supprimerEtudiant);

module.exports = router;
