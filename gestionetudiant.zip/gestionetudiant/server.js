const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const session = require('express-session');

dotenv.config();

const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(express.static('public'));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(session({
  secret: 'votre_secret_ici', // Mets un secret fort pour sécuriser les cookies
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // mettre true si HTTPS
}));

// Routes
const authRoutes = require('./routes/authRoutes');
const etudiantRoutes = require('./routes/etudiantRoutes');

app.use('/', authRoutes);
app.use('/etudiants', etudiantRoutes);

// Redirection vers /login si quelqu'un accède à /
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Lancement du serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`);
});

